# Chimney Service Reminder – 2 Person Shared + Offline Sync

This version changes the app from device-only SQLite storage to Firebase Firestore + Firebase Auth.

## What it does
- Two people can use the same shared Group ID.
- Customer records added/changed/deleted by either person appear on the other person's phone.
- Firestore mobile offline persistence queues writes while offline and syncs when internet returns.
- Login protects the shared data.
- Customer amount, paid amount, pending balance, service history and 3-month renewal are included.

## Important: one-time Firebase setup
This source needs a Firebase project before it can run. Add Android Firebase configuration using FlutterFire CLI (`flutterfire configure`) so that `firebase_options.dart` and Android `google-services.json` are generated. Enable:
1. Firebase Authentication -> Email/Password
2. Cloud Firestore

## Two-person sharing
Create two Firebase accounts (one for each person). Give both accounts the exact same Group ID, e.g. `CHIMNEY001`. For real production use, add Firestore Security Rules so only the two authorized UIDs can access that group's data. The UI is prepared for the shared-group model.

## Build
flutter pub get
flutterfire configure
flutter build apk --release

## Offline behavior
Firestore caches data on Android. Reads continue from local cache, and creates/updates/deletes made offline are synchronized when connectivity returns. Avoid editing the same customer on both phones at exactly the same time; the last successful write can win.
